Andys To-Do App 

Simply Clone the Repository to your Device, and run, npm install, and npx expo start

The Mini App is build around the Expo go App Version 50 so make sure you have the correct version installed
